import { i as __toESM } from "../_runtime.mjs";
import { L as require_react, v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Pause, c as Maximize2, i as Play, o as Minimize2, r as Square, s as Mic, t as Upload } from "../_libs/lucide-react.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-jZ5ERT2D.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function getAudioContextCtor() {
	const w = globalThis;
	const Ctor = w.AudioContext ?? w.webkitAudioContext;
	if (!Ctor) throw new Error("Web Audio is not supported in this browser.");
	return Ctor;
}
function createNoiseBuffer(ctx) {
	const length = ctx.sampleRate * 1;
	const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
	const data = buffer.getChannelData(0);
	for (let i = 0; i < length; i++) data[i] = Math.random() * 2 - 1;
	return buffer;
}
var ARP = [
	110,
	130.81,
	146.83,
	164.81,
	196,
	220,
	246.94,
	293.66
];
var AudioEngine = class {
	ctx = null;
	analyser = null;
	audioEl = null;
	sourceGain = null;
	outputGain = null;
	freqData = null;
	timeData = null;
	mediaSource = null;
	objectUrl = null;
	micSource = null;
	micStream = null;
	demoNodes = [];
	demoCleanup = null;
	demoGain = null;
	kind = "idle";
	volume = .85;
	ensure() {
		if (this.ctx) return this.ctx;
		const ctx = new (getAudioContextCtor())({ latencyHint: "interactive" });
		const analyser = ctx.createAnalyser();
		analyser.fftSize = 2048;
		analyser.smoothingTimeConstant = .78;
		analyser.minDecibels = -88;
		analyser.maxDecibels = -18;
		const sourceGain = ctx.createGain();
		sourceGain.gain.value = 1;
		const outputGain = ctx.createGain();
		outputGain.gain.value = this.volume * this.volume;
		sourceGain.connect(analyser);
		sourceGain.connect(outputGain);
		outputGain.connect(ctx.destination);
		this.ctx = ctx;
		this.analyser = analyser;
		this.sourceGain = sourceGain;
		this.outputGain = outputGain;
		this.freqData = new Uint8Array(analyser.frequencyBinCount);
		this.timeData = new Uint8Array(analyser.fftSize);
		return ctx;
	}
	resume() {
		const ctx = this.ensure();
		if (ctx.state === "suspended") ctx.resume();
	}
	setVolume(v) {
		this.volume = v;
		const ctx = this.ctx;
		const out = this.outputGain;
		if (!ctx || !out) return;
		const target = this.kind === "mic" ? 0 : v * v;
		out.gain.setTargetAtTime(target, ctx.currentTime, .03);
	}
	getFrequencyData() {
		if (!this.analyser || !this.freqData) return null;
		this.analyser.getByteFrequencyData(this.freqData);
		return this.freqData;
	}
	getTimeData() {
		if (!this.analyser || !this.timeData) return null;
		this.analyser.getByteTimeDomainData(this.timeData);
		return this.timeData;
	}
	muteOutput(mute) {
		const ctx = this.ctx;
		const out = this.outputGain;
		if (!ctx || !out) return;
		const target = mute ? 0 : this.volume * this.volume;
		out.gain.setTargetAtTime(target, ctx.currentTime, .02);
	}
	stopMic() {
		this.micSource?.disconnect();
		this.micSource = null;
		this.micStream?.getTracks().forEach((t) => t.stop());
		this.micStream = null;
	}
	stopDemo() {
		this.demoCleanup?.();
		this.demoCleanup = null;
		for (const node of this.demoNodes) {
			try {
				node.stop();
			} catch {}
			try {
				node.disconnect();
			} catch {}
		}
		this.demoNodes = [];
		this.demoGain?.disconnect();
		this.demoGain = null;
	}
	pauseFile() {
		if (this.audioEl && !this.audioEl.paused) this.audioEl.pause();
	}
	stopAll() {
		this.stopMic();
		this.stopDemo();
		this.pauseFile();
		this.kind = "idle";
		this.muteOutput(false);
	}
	async startMic() {
		this.resume();
		this.stopDemo();
		this.pauseFile();
		this.stopMic();
		this.muteOutput(true);
		const stream = await navigator.mediaDevices.getUserMedia({ audio: {
			echoCancellation: true,
			noiseSuppression: true,
			autoGainControl: true
		} });
		const source = this.ctx.createMediaStreamSource(stream);
		source.connect(this.sourceGain);
		this.micStream = stream;
		this.micSource = source;
		this.kind = "mic";
	}
	async loadFile(file) {
		this.resume();
		this.stopMic();
		this.stopDemo();
		const ctx = this.ctx;
		if (!this.audioEl) {
			const el = new Audio();
			el.crossOrigin = "anonymous";
			el.preload = "auto";
			this.mediaSource = ctx.createMediaElementSource(el);
			this.mediaSource.connect(this.sourceGain);
			this.audioEl = el;
		}
		if (this.objectUrl) URL.revokeObjectURL(this.objectUrl);
		this.objectUrl = URL.createObjectURL(file);
		this.audioEl.src = this.objectUrl;
		this.audioEl.currentTime = 0;
		this.kind = "file";
		this.muteOutput(false);
		await this.audioEl.play();
		return this.audioEl;
	}
	async playFile() {
		if (!this.audioEl) return;
		this.resume();
		this.kind = "file";
		this.muteOutput(false);
		await this.audioEl.play();
	}
	pause() {
		if (this.kind === "file") {
			this.pauseFile();
			return;
		}
		if (this.kind === "demo") {
			this.demoGain?.gain.setTargetAtTime(0, this.ctx?.currentTime ?? 0, .04);
			if (this.ctx?.state === "running") this.ctx.suspend();
		}
	}
	async resumePlayback() {
		this.resume();
		if (this.kind === "file") await this.audioEl?.play();
		if (this.kind === "demo") this.demoGain?.gain.setTargetAtTime(.9, this.ctx?.currentTime ?? 0, .04);
	}
	seek(t) {
		if (this.audioEl) this.audioEl.currentTime = t;
	}
	startDemo() {
		this.resume();
		this.stopMic();
		this.pauseFile();
		this.stopDemo();
		const ctx = this.ctx;
		this.kind = "demo";
		this.muteOutput(false);
		const demoGain = ctx.createGain();
		demoGain.gain.value = .9;
		demoGain.connect(this.sourceGain);
		this.demoGain = demoGain;
		const filter = ctx.createBiquadFilter();
		filter.type = "lowpass";
		filter.frequency.value = 720;
		filter.Q.value = 3.2;
		filter.connect(demoGain);
		const padGain = ctx.createGain();
		padGain.gain.value = .045;
		padGain.connect(filter);
		const pad = ctx.createOscillator();
		pad.type = "sawtooth";
		pad.frequency.value = 55;
		const pad2 = ctx.createOscillator();
		pad2.type = "sawtooth";
		pad2.frequency.value = 55.4;
		pad.connect(padGain);
		pad2.connect(padGain);
		const lfo = ctx.createOscillator();
		lfo.type = "sine";
		lfo.frequency.value = .18;
		const lfoGain = ctx.createGain();
		lfoGain.gain.value = 480;
		lfo.connect(lfoGain);
		lfoGain.connect(filter.frequency);
		const noiseBuf = createNoiseBuffer(ctx);
		pad.start();
		pad2.start();
		lfo.start();
		this.demoNodes.push(pad, pad2, lfo);
		let step = 0;
		let next = ctx.currentTime + .05;
		let timer = null;
		let stopped = false;
		const schedule = () => {
			if (stopped || !this.ctx) return;
			const now = this.ctx.currentTime;
			while (next < now + .25) {
				this.scheduleKick(next, demoGain);
				if (step % 2 === 1) this.scheduleHat(next, noiseBuf, demoGain);
				if (step % 4 !== 3) this.scheduleArp(next, step, demoGain);
				next += .5;
				step += 1;
			}
		};
		schedule();
		timer = window.setInterval(schedule, 80);
		this.demoCleanup = () => {
			stopped = true;
			if (timer != null) window.clearInterval(timer);
			padGain.disconnect();
			filter.disconnect();
			lfoGain.disconnect();
		};
	}
	scheduleKick(when, dest) {
		const ctx = this.ctx;
		const osc = ctx.createOscillator();
		osc.type = "sine";
		const g = ctx.createGain();
		osc.frequency.setValueAtTime(128, when);
		osc.frequency.exponentialRampToValueAtTime(42, when + .18);
		g.gain.setValueAtTime(1e-4, when);
		g.gain.exponentialRampToValueAtTime(.7, when + .01);
		g.gain.exponentialRampToValueAtTime(1e-4, when + .28);
		osc.connect(g);
		g.connect(dest);
		osc.start(when);
		osc.stop(when + .3);
		osc.onended = () => {
			osc.disconnect();
			g.disconnect();
		};
	}
	scheduleHat(when, buf, dest) {
		const ctx = this.ctx;
		const src = ctx.createBufferSource();
		src.buffer = buf;
		const bp = ctx.createBiquadFilter();
		bp.type = "highpass";
		bp.frequency.value = 6e3;
		const g = ctx.createGain();
		g.gain.setValueAtTime(1e-4, when);
		g.gain.exponentialRampToValueAtTime(.12, when + .005);
		g.gain.exponentialRampToValueAtTime(1e-4, when + .07);
		src.connect(bp);
		bp.connect(g);
		g.connect(dest);
		src.start(when);
		src.stop(when + .08);
		src.onended = () => {
			src.disconnect();
			bp.disconnect();
			g.disconnect();
		};
	}
	scheduleArp(when, step, dest) {
		const ctx = this.ctx;
		const freq = ARP[step % ARP.length] ?? 220;
		const osc = ctx.createOscillator();
		osc.type = "triangle";
		osc.frequency.value = freq * 2;
		const g = ctx.createGain();
		g.gain.setValueAtTime(1e-4, when);
		g.gain.exponentialRampToValueAtTime(.09, when + .02);
		g.gain.exponentialRampToValueAtTime(1e-4, when + .36);
		const f = ctx.createBiquadFilter();
		f.type = "lowpass";
		f.frequency.value = 1800;
		osc.connect(f);
		f.connect(g);
		g.connect(dest);
		osc.start(when);
		osc.stop(when + .4);
		osc.onended = () => {
			osc.disconnect();
			f.disconnect();
			g.disconnect();
		};
	}
	dispose() {
		this.stopAll();
		if (this.objectUrl) URL.revokeObjectURL(this.objectUrl);
		this.objectUrl = null;
		this.ctx?.close();
		this.ctx = null;
	}
};
var audioEngine = new AudioEngine();
var useVizStore = create()(persist((set) => ({
	mode: "spire",
	theme: "ember",
	sensitivity: 1.15,
	volume: .85,
	source: "idle",
	playing: false,
	fileName: null,
	duration: 0,
	currentTime: 0,
	error: null,
	fullscreen: false,
	hudPinned: false,
	setMode: (mode) => set({ mode }),
	setTheme: (theme) => set({ theme }),
	setSensitivity: (sensitivity) => set({ sensitivity }),
	setVolume: (volume) => set({ volume }),
	setSource: (source) => set({ source }),
	setPlaying: (playing) => set({ playing }),
	setFileMeta: (fileName, duration) => set({
		fileName,
		duration
	}),
	setCurrentTime: (currentTime) => set({ currentTime }),
	setError: (error) => set({ error }),
	setFullscreen: (fullscreen) => set({ fullscreen }),
	setHudPinned: (hudPinned) => set({ hudPinned })
}), {
	name: "vanta-viz",
	partialize: (s) => ({
		mode: s.mode,
		theme: s.theme,
		sensitivity: s.sensitivity,
		volume: s.volume
	})
}));
function mapSpectrum(freq, out, sensitivity) {
	const n = out.length;
	const len = freq.length;
	if (len < 2) {
		out.fill(0);
		return;
	}
	const logMin = Math.log(1);
	const logMax = Math.log(len - 1);
	for (let i = 0; i < n; i++) {
		const t0 = i / n;
		const t1 = (i + 1) / n;
		const b0 = Math.max(1, Math.floor(Math.exp(logMin + (logMax - logMin) * t0)));
		const b1 = Math.max(b0 + 1, Math.floor(Math.exp(logMin + (logMax - logMin) * t1)));
		let sum = 0;
		const end = Math.min(b1, len);
		for (let b = b0; b < end; b++) sum += freq[b] ?? 0;
		const avg = sum / Math.max(1, end - b0);
		const bassBoost = .82 + .32 * (1 - t0);
		out[i] = Math.min(1, avg / 255 * sensitivity * bassBoost);
	}
}
function idleSpectrum(out, time) {
	const n = out.length;
	for (let i = 0; i < n; i++) {
		const x = n === 1 ? 0 : i / (n - 1);
		const wave = .2 * Math.sin(time * .55 + x * 5.4) + .1 * Math.sin(time * 1.15 + x * 12.6) + .07 * Math.sin(time * .32 + x * 2.1);
		const envelope = Math.exp(-Math.pow((x - .16) * 2.5, 2)) * .42 + Math.exp(-Math.pow((x - .52) * 3.1, 2)) * .22 + Math.exp(-Math.pow((x - .84) * 4.2, 2)) * .12 + .1;
		out[i] = Math.max(.035, envelope + wave * .14);
	}
}
function smoothToward(current, target, dt, rate) {
	const k = 1 - Math.exp(-dt * rate);
	for (let i = 0; i < current.length; i++) {
		const c = current[i] ?? 0;
		const t = target[i] ?? 0;
		current[i] = c + (t - c) * k;
	}
}
function decayPeaks(peaks, values, dt, fall) {
	for (let i = 0; i < peaks.length; i++) {
		const v = values[i] ?? 0;
		const p = peaks[i] ?? 0;
		peaks[i] = v > p ? v : Math.max(0, p - fall * dt);
	}
}
function bandEnergy(values, start, end) {
	const a = Math.max(0, Math.floor(start * values.length));
	const b = Math.min(values.length, Math.ceil(end * values.length));
	if (b <= a) return 0;
	let sum = 0;
	for (let i = a; i < b; i++) sum += values[i] ?? 0;
	return sum / (b - a);
}
function lerp(a, b, t) {
	return a + (b - a) * t;
}
function mix(a, b, t) {
	return [
		lerp(a[0], b[0], t),
		lerp(a[1], b[1], t),
		lerp(a[2], b[2], t)
	];
}
function rgba(c, a) {
	return `rgba(${c[0] | 0},${c[1] | 0},${c[2] | 0},${a})`;
}
function barColor(theme, x, amp) {
	return mix(mix(theme.low, theme.high, x), theme.mid, Math.min(1, amp * 1.15));
}
function fillTrail(ctx, w, h, alpha) {
	ctx.globalCompositeOperation = "source-over";
	ctx.fillStyle = `rgba(5,5,6,${alpha})`;
	ctx.fillRect(0, 0, w, h);
}
function vignette(ctx, w, h) {
	const g = ctx.createRadialGradient(w * .5, h * .5, Math.min(w, h) * .2, w * .5, h * .5, Math.max(w, h) * .72);
	g.addColorStop(0, "rgba(0,0,0,0)");
	g.addColorStop(1, "rgba(0,0,0,0.55)");
	ctx.fillStyle = g;
	ctx.fillRect(0, 0, w, h);
}
function bloom(ctx, x, y, r, color, alpha) {
	const g = ctx.createRadialGradient(x, y, 0, x, y, r);
	g.addColorStop(0, rgba(color, alpha));
	g.addColorStop(.4, rgba(color, alpha * .35));
	g.addColorStop(1, rgba(color, 0));
	ctx.fillStyle = g;
	ctx.beginPath();
	ctx.arc(x, y, r, 0, Math.PI * 2);
	ctx.fill();
}
function drawNeedle(ctx, x0, y0, x1, y1, amp, color, glow) {
	const dx = x1 - x0;
	const dy = y1 - y0;
	const len = Math.hypot(dx, dy) || 1;
	const nx = -dy / len;
	const ny = dx / len;
	const baseW = 1.1 + amp * 2.4;
	const tipW = .35 + amp * .6;
	ctx.beginPath();
	ctx.moveTo(x0 + nx * baseW, y0 + ny * baseW);
	ctx.lineTo(x0 - nx * baseW, y0 - ny * baseW);
	ctx.lineTo(x1 - nx * tipW, y1 - ny * tipW);
	ctx.lineTo(x1 + nx * tipW, y1 + ny * tipW);
	ctx.closePath();
	ctx.fillStyle = rgba(color, .22 + amp * .7);
	ctx.fill();
	ctx.beginPath();
	ctx.moveTo(x0, y0);
	ctx.lineTo(x1, y1);
	ctx.strokeStyle = rgba(color, .35 + amp * .55);
	ctx.lineWidth = .8;
	ctx.stroke();
	const orb = 1.6 + amp * 6.5;
	bloom(ctx, x1, y1, orb * 2.8, glow, .12 + amp * .28);
	ctx.beginPath();
	ctx.arc(x1, y1, Math.max(1.1, orb * .38), 0, Math.PI * 2);
	ctx.fillStyle = rgba([
		255,
		255,
		255
	], .45 + amp * .5);
	ctx.fill();
	ctx.beginPath();
	ctx.arc(x1, y1, orb * .72, 0, Math.PI * 2);
	ctx.fillStyle = rgba(glow, .55 + amp * .35);
	ctx.fill();
}
function drawSpire(frame) {
	const { ctx, width: w, height: h, values, peaks, theme, bass } = frame;
	const n = values.length;
	const horizon = h * .58;
	const up = h * .42;
	const down = h * .26;
	const margin = w * .07;
	const span = w * .86;
	const slot = span / n;
	bloom(ctx, w * .5, horizon, w * .42, theme.glow, .04 + bass * .1);
	const hg = ctx.createLinearGradient(margin, 0, margin + span, 0);
	hg.addColorStop(0, "rgba(255,255,255,0)");
	hg.addColorStop(.5, rgba(theme.glow, .35 + bass * .25));
	hg.addColorStop(1, "rgba(255,255,255,0)");
	ctx.beginPath();
	ctx.moveTo(margin, horizon);
	ctx.lineTo(margin + span, horizon);
	ctx.strokeStyle = hg;
	ctx.lineWidth = 1;
	ctx.stroke();
	const tips = [];
	for (let i = 0; i < n; i++) {
		const amp = values[i] ?? 0;
		const peak = peaks[i] ?? amp;
		const x = margin + (i + .5) * slot;
		const color = barColor(theme, n === 1 ? 0 : i / (n - 1), amp);
		const y1 = horizon - amp * up;
		drawNeedle(ctx, x, horizon, x, y1, amp, color, theme.glow);
		tips.push({
			x,
			y: y1,
			amp
		});
		const py = horizon - peak * up;
		ctx.beginPath();
		ctx.arc(x, py, 1.15, 0, Math.PI * 2);
		ctx.fillStyle = rgba(theme.high, .25 + peak * .5);
		ctx.fill();
		ctx.save();
		ctx.globalAlpha = .28;
		drawNeedle(ctx, x, horizon, x, horizon + amp * down, amp * .85, color, theme.glow);
		ctx.restore();
	}
	ctx.beginPath();
	let linked = false;
	for (let i = 0; i < tips.length; i++) {
		const a = tips[i];
		if (a.amp < .62) {
			linked = false;
			continue;
		}
		if (!linked) {
			ctx.moveTo(a.x, a.y);
			linked = true;
		} else {
			const prev = tips[i - 1];
			const mx = (prev.x + a.x) / 2;
			const my = Math.min(prev.y, a.y) - 8;
			ctx.quadraticCurveTo(mx, my, a.x, a.y);
		}
	}
	ctx.strokeStyle = rgba(theme.glow, .22);
	ctx.lineWidth = 1;
	ctx.stroke();
	const fade = ctx.createLinearGradient(0, horizon, 0, h);
	fade.addColorStop(0, "rgba(5,5,6,0)");
	fade.addColorStop(.55, "rgba(5,5,6,0.35)");
	fade.addColorStop(1, "rgba(5,5,6,0.88)");
	ctx.fillStyle = fade;
	ctx.fillRect(0, horizon, w, h - horizon);
}
function drawOrbit(frame) {
	const { ctx, width: w, height: h, values, peaks, theme, time, bass, energy, timeDomain } = frame;
	const n = values.length;
	const cx = w * .5;
	const cy = h * .5;
	const maxR = Math.min(w, h) * .38;
	const inner = Math.min(w, h) * (.07 + bass * .045);
	const rot = time * .12 + energy * .4;
	bloom(ctx, cx, cy, maxR * 1.35, theme.glow, .05 + bass * .12);
	ctx.beginPath();
	ctx.arc(cx, cy, maxR * 1.05, 0, Math.PI * 2);
	ctx.strokeStyle = rgba(theme.mid, .12 + energy * .12);
	ctx.lineWidth = 1;
	ctx.stroke();
	ctx.beginPath();
	ctx.arc(cx, cy, inner * 1.15, 0, Math.PI * 2);
	ctx.strokeStyle = rgba(theme.glow, .35 + bass * .4);
	ctx.lineWidth = 1.4;
	ctx.stroke();
	for (let i = 0; i < n; i++) {
		const amp = values[i] ?? 0;
		const peak = peaks[i] ?? amp;
		const t = n === 1 ? 0 : i / (n - 1);
		const ang = rot + t * Math.PI * 2;
		const cos = Math.cos(ang);
		const sin = Math.sin(ang);
		const r0 = inner;
		const r1 = inner + amp * (maxR - inner);
		drawNeedle(ctx, cx + cos * r0, cy + sin * r0, cx + cos * r1, cy + sin * r1, amp, barColor(theme, t, amp), theme.glow);
		const pr = inner + peak * (maxR - inner);
		ctx.beginPath();
		ctx.arc(cx + cos * pr, cy + sin * pr, 1.1, 0, Math.PI * 2);
		ctx.fillStyle = rgba(theme.high, .3 + peak * .4);
		ctx.fill();
	}
	if (timeDomain && timeDomain.length > 4) {
		ctx.beginPath();
		const steps = 128;
		for (let i = 0; i <= steps; i++) {
			const v = ((timeDomain[Math.floor(i / steps * (timeDomain.length - 1))] ?? 128) - 128) / 128;
			const r = inner * .55 + v * inner * .45;
			const a = i / steps * Math.PI * 2 + time * .4;
			const x = cx + Math.cos(a) * r;
			const y = cy + Math.sin(a) * r;
			if (i === 0) ctx.moveTo(x, y);
			else ctx.lineTo(x, y);
		}
		ctx.closePath();
		ctx.strokeStyle = rgba(theme.high, .35);
		ctx.lineWidth = 1.2;
		ctx.stroke();
	}
	bloom(ctx, cx, cy, inner * 2.2, theme.glow, .2 + bass * .35);
	ctx.beginPath();
	ctx.arc(cx, cy, inner * .42, 0, Math.PI * 2);
	ctx.fillStyle = rgba(theme.high, .7);
	ctx.fill();
}
function drawHalo(frame) {
	const { ctx, width: w, height: h, values, theme, time, bass, energy, timeDomain } = frame;
	const cx = w * .5;
	const cy = h * .52;
	const maxR = Math.min(w, h) * .4;
	const bands = 7;
	bloom(ctx, cx, cy, maxR * 1.2, theme.glow, .05 + bass * .14);
	for (let b = 0; b < bands; b++) {
		const t0 = b / bands;
		const e = bandEnergy(values, t0, (b + 1) / bands);
		const radius = maxR * (.22 + t0 * .78) * (1 + bass * .03);
		const lw = 1 + e * (10 - b * .7);
		const start = time * (.08 + b * .05) * (b % 2 === 0 ? 1 : -1) + b * .7;
		const span = Math.PI * (.55 + e * 1.15);
		const color = barColor(theme, t0, e);
		ctx.beginPath();
		ctx.arc(cx, cy, radius, start, start + span);
		ctx.strokeStyle = rgba(color, .18 + e * .7);
		ctx.lineWidth = lw;
		ctx.lineCap = "round";
		ctx.stroke();
		ctx.beginPath();
		ctx.arc(cx, cy, radius, start + Math.PI, start + Math.PI + span * .7);
		ctx.strokeStyle = rgba(color, .1 + e * .35);
		ctx.lineWidth = Math.max(1, lw * .45);
		ctx.stroke();
	}
	const ticks = 48;
	for (let i = 0; i < ticks; i++) {
		const amp = values[Math.floor(i / ticks * values.length)] ?? 0;
		const ang = i / ticks * Math.PI * 2 + time * .05;
		const r0 = maxR * .12;
		const r1 = r0 + amp * maxR * .16;
		ctx.beginPath();
		ctx.moveTo(cx + Math.cos(ang) * r0, cy + Math.sin(ang) * r0);
		ctx.lineTo(cx + Math.cos(ang) * r1, cy + Math.sin(ang) * r1);
		ctx.strokeStyle = rgba(theme.mid, .25 + amp * .55);
		ctx.lineWidth = 1.2;
		ctx.stroke();
	}
	if (timeDomain && timeDomain.length > 8) {
		ctx.beginPath();
		const steps = 180;
		for (let i = 0; i <= steps; i++) {
			const v = ((timeDomain[Math.floor(i / steps * (timeDomain.length - 1))] ?? 128) - 128) / 128;
			const r = maxR * .1 + v * maxR * .08 + bass * maxR * .04;
			const a = i / steps * Math.PI * 2;
			const x = cx + Math.cos(a) * r;
			const y = cy + Math.sin(a) * r;
			if (i === 0) ctx.moveTo(x, y);
			else ctx.lineTo(x, y);
		}
		ctx.closePath();
		ctx.fillStyle = rgba(theme.glow, .08 + energy * .1);
		ctx.fill();
		ctx.strokeStyle = rgba(theme.high, .4);
		ctx.lineWidth = 1;
		ctx.stroke();
	}
	ctx.beginPath();
	ctx.arc(cx, cy, 3 + bass * 6, 0, Math.PI * 2);
	ctx.fillStyle = rgba(theme.high, .85);
	ctx.fill();
}
function drawVisualizer(frame) {
	const { ctx, width, height, theme, bass, mode } = frame;
	fillTrail(ctx, width, height, .24);
	bloom(ctx, width * .5, height * .5, Math.max(width, height) * .45, theme.glow, .03 + bass * .07);
	if (mode === "spire") drawSpire(frame);
	else if (mode === "orbit") drawOrbit(frame);
	else drawHalo(frame);
	vignette(ctx, width, height);
}
var THEMES = {
	ember: {
		id: "ember",
		name: "Ember",
		low: [
			72,
			18,
			12
		],
		mid: [
			255,
			92,
			58
		],
		high: [
			255,
			214,
			186
		],
		glow: [
			255,
			110,
			64
		]
	},
	ice: {
		id: "ice",
		name: "Ice",
		low: [
			8,
			36,
			56
		],
		mid: [
			110,
			200,
			255
		],
		high: [
			232,
			246,
			255
		],
		glow: [
			140,
			214,
			255
		]
	},
	sage: {
		id: "sage",
		name: "Sage",
		low: [
			10,
			40,
			24
		],
		mid: [
			61,
			204,
			138
		],
		high: [
			210,
			255,
			230
		],
		glow: [
			90,
			230,
			168
		]
	},
	pearl: {
		id: "pearl",
		name: "Pearl",
		low: [
			36,
			36,
			40
		],
		mid: [
			200,
			200,
			206
		],
		high: [
			255,
			255,
			255
		],
		glow: [
			232,
			232,
			236
		]
	}
};
var THEME_LIST = [
	THEMES.ember,
	THEMES.ice,
	THEMES.sage,
	THEMES.pearl
];
var MODES = [
	{
		id: "spire",
		label: "Spire"
	},
	{
		id: "orbit",
		label: "Orbit"
	},
	{
		id: "halo",
		label: "Halo"
	}
];
function VisualizerCanvas() {
	const canvasRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		const ctx = canvas.getContext("2d", { alpha: false });
		if (!ctx) return;
		const target = /* @__PURE__ */ new Float32Array(96);
		const smoothed = /* @__PURE__ */ new Float32Array(96);
		const peaks = /* @__PURE__ */ new Float32Array(96);
		idleSpectrum(smoothed, 0);
		let raf = 0;
		let last = performance.now();
		let disposed = false;
		const resize = () => {
			const dpr = Math.min(window.devicePixelRatio || 1, 2);
			const w = canvas.clientWidth;
			const h = canvas.clientHeight;
			canvas.width = Math.max(1, Math.floor(w * dpr));
			canvas.height = Math.max(1, Math.floor(h * dpr));
			ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
		};
		resize();
		const ro = new ResizeObserver(resize);
		ro.observe(canvas);
		const loop = (now) => {
			if (disposed) return;
			const dt = Math.min((now - last) / 1e3, .1);
			last = now;
			const state = useVizStore.getState();
			const freq = audioEngine.getFrequencyData();
			const hasSignal = Boolean(freq) && state.playing && state.source !== "idle";
			if (hasSignal && freq) mapSpectrum(freq, target, state.sensitivity);
			else idleSpectrum(target, now / 1e3);
			smoothToward(smoothed, target, dt, hasSignal ? 14 : 3.2);
			decayPeaks(peaks, smoothed, dt, hasSignal ? .42 : .12);
			const bass = bandEnergy(smoothed, 0, .12);
			const energy = bandEnergy(smoothed, 0, 1);
			const w = canvas.clientWidth;
			const h = canvas.clientHeight;
			drawVisualizer({
				ctx,
				width: w,
				height: h,
				values: smoothed,
				peaks,
				timeDomain: hasSignal ? audioEngine.getTimeData() : null,
				theme: THEMES[state.theme],
				mode: state.mode,
				time: now / 1e3,
				bass,
				energy,
				playing: state.playing
			});
			raf = requestAnimationFrame(loop);
		};
		raf = requestAnimationFrame(loop);
		return () => {
			disposed = true;
			cancelAnimationFrame(raf);
			ro.disconnect();
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
		ref: canvasRef,
		className: "pointer-events-none absolute inset-0 size-full bg-bg",
		"aria-hidden": "true"
	});
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function formatTime(seconds) {
	if (!Number.isFinite(seconds) || seconds < 0) return "0:00";
	return `${Math.floor(seconds / 60)}:${Math.floor(seconds % 60).toString().padStart(2, "0")}`;
}
var THEME_SWATCH = {
	ember: "bg-ember",
	ice: "bg-ice",
	sage: "bg-sage",
	pearl: "bg-pearl"
};
function VisualizerHud({ visible, onMic, onUpload, onDemo, onTogglePlay, onStop, onSeek, onFullscreen }) {
	const fileRef = (0, import_react.useRef)(null);
	const source = useVizStore((s) => s.source);
	const playing = useVizStore((s) => s.playing);
	const mode = useVizStore((s) => s.mode);
	const theme = useVizStore((s) => s.theme);
	const sensitivity = useVizStore((s) => s.sensitivity);
	const volume = useVizStore((s) => s.volume);
	const fileName = useVizStore((s) => s.fileName);
	const duration = useVizStore((s) => s.duration);
	const currentTime = useVizStore((s) => s.currentTime);
	const fullscreen = useVizStore((s) => s.fullscreen);
	const error = useVizStore((s) => s.error);
	const setMode = useVizStore((s) => s.setMode);
	const setTheme = useVizStore((s) => s.setTheme);
	const setSensitivity = useVizStore((s) => s.setSensitivity);
	const setVolume = useVizStore((s) => s.setVolume);
	const idle = source === "idle";
	const canTransport = source === "file" || source === "demo";
	const showProgress = source === "file" && duration > 0;
	const status = source === "mic" ? "Listening" : source === "demo" ? "Demo pulse" : source === "file" ? fileName ?? "Track" : "Ready";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: cn("hud-fade pointer-events-none absolute inset-x-0 top-0 z-20 flex items-start justify-between gap-4 px-4 pt-4 sm:px-6 sm:pt-6", "transition-opacity duration-200 ease-out", visible ? "opacity-100" : "opacity-0"),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("pointer-events-auto", idle && "opacity-0"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-lg font-semibold tracking-display text-fg sm:text-xl",
					children: "Vanta"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-0.5 text-xs tracking-wide text-muted",
					children: "Listen in the dark"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-auto flex flex-col items-end gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "hud-panel flex rounded-xl p-1",
					children: MODES.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModeButton, {
						active: mode === m.id,
						label: m.label,
						onClick: () => setMode(m.id)
					}, m.id))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "hud-panel flex items-center gap-1 rounded-xl px-2 py-1.5",
					children: THEME_LIST.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						"aria-label": `${t.name} theme`,
						"aria-pressed": theme === t.id,
						onClick: () => setTheme(t.id),
						className: "pressable relative flex size-11 items-center justify-center rounded-lg sm:size-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-3.5 rounded-full", THEME_SWATCH[t.id], theme === t.id ? "opacity-100" : "opacity-55") }), theme === t.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute inset-1 rounded-md ring-1 ring-fg/40" }) : null]
					}, t.id))
				})]
			})]
		}),
		idle ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "absolute inset-0 z-10 flex items-center justify-center px-5",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex w-full max-w-lg flex-col items-center text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-5xl font-semibold tracking-display text-fg sm:text-7xl",
						children: "Vanta"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-sm text-sm leading-relaxed text-muted sm:text-base",
						children: "A black-field visualizer. Feed it a microphone or a track and watch light gather at the edges of sound."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex w-full flex-col gap-3 sm:flex-row",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SourceButton, {
								icon: Mic,
								label: "Microphone",
								onClick: onMic
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SourceButton, {
								icon: Upload,
								label: "Upload track",
								onClick: () => fileRef.current?.click()
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SourceButton, {
								icon: Play,
								label: "Play demo",
								onClick: onDemo,
								primary: true
							})
						]
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm text-ember",
						role: "alert",
						children: error
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 hidden text-xs text-subtle sm:block",
						children: "Space play · F fullscreen · 1–3 modes"
					})
				]
			})
		}) : null,
		!idle ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
			className: cn("hud-fade pointer-events-none absolute inset-x-0 bottom-0 z-20 px-3 pb-3 sm:px-6 sm:pb-6", "transition-opacity duration-200 ease-out", visible ? "opacity-100" : "opacity-0"),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-auto hud-panel mx-auto flex max-w-3xl flex-col gap-3 rounded-xl p-3 sm:rounded-2xl sm:p-4",
				children: [
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-ember",
						role: "alert",
						children: error
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 sm:gap-3",
						children: [
							canTransport ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
								label: playing ? "Pause" : "Play",
								onClick: onTogglePlay,
								children: playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-5 translate-x-px" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
								label: "Stop",
								onClick: onStop,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, { className: "size-4 fill-current" })
							})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
								label: "Stop microphone",
								onClick: onStop,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, { className: "size-4 fill-current" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-xs font-medium tracking-wide text-fg",
									children: status
								}), showProgress ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-1.5 flex items-center gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "w-8 text-xs tabular-nums text-subtle",
											children: formatTime(currentTime)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "range",
											min: 0,
											max: duration,
											step: .01,
											value: Math.min(currentTime, duration),
											onChange: (e) => onSeek(Number(e.target.value)),
											"aria-label": "Seek",
											className: "range-input"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "w-8 text-right text-xs tabular-nums text-subtle",
											children: formatTime(duration)
										})
									]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-0.5 text-xs text-subtle",
									children: source === "mic" ? "Live input" : "Generative pulse"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
								label: "Microphone",
								onClick: onMic,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "size-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
								label: "Upload track",
								onClick: () => fileRef.current?.click(),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
								label: fullscreen ? "Exit fullscreen" : "Enter fullscreen",
								onClick: onFullscreen,
								children: fullscreen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minimize2, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize2, { className: "size-4" })
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-3 sm:flex-row sm:items-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex min-w-0 flex-1 items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "w-20 shrink-0 text-xs font-medium tracking-wide text-muted",
								children: "Sensitivity"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "range",
								min: .4,
								max: 2.4,
								step: .01,
								value: sensitivity,
								onChange: (e) => setSensitivity(Number(e.target.value)),
								className: "range-input"
							})]
						}), source !== "mic" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex min-w-0 flex-1 items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "w-20 shrink-0 text-xs font-medium tracking-wide text-muted",
								children: "Volume"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "range",
								min: 0,
								max: 1,
								step: .01,
								value: volume,
								onChange: (e) => setVolume(Number(e.target.value)),
								className: "range-input"
							})]
						}) : null]
					})
				]
			})
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			ref: fileRef,
			type: "file",
			accept: "audio/*,.mp3,.wav,.ogg,.m4a,.flac,.aac",
			className: "hidden",
			suppressHydrationWarning: true,
			onChange: (e) => {
				const file = e.target.files?.[0];
				if (file) onUpload(file);
				e.target.value = "";
			}
		})
	] });
}
function ModeButton({ active, label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		"aria-pressed": active,
		className: cn("pressable min-h-11 rounded-lg px-3 text-xs font-medium tracking-wide sm:min-h-8", active ? "bg-surface-2 text-fg" : "text-muted hover:text-fg"),
		children: label
	});
}
function SourceButton({ icon: Icon, label, onClick, primary }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: cn("pressable flex min-h-12 flex-1 items-center justify-center gap-2 rounded-xl px-4 text-sm font-medium", primary ? "bg-accent text-accent-fg" : "hud-panel text-fg"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: cn("size-4", primary && "translate-x-px") }), label]
	});
}
function IconBtn({ label, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-label": label,
		onClick,
		className: "pressable flex size-11 shrink-0 items-center justify-center rounded-lg text-fg hover:bg-surface-2",
		children
	});
}
function VisualizerApp() {
	const rootRef = (0, import_react.useRef)(null);
	const [hudVisible, setHudVisible] = (0, import_react.useState)(true);
	const hideTimer = (0, import_react.useRef)(null);
	const source = useVizStore((s) => s.source);
	const playing = useVizStore((s) => s.playing);
	const volume = useVizStore((s) => s.volume);
	const hudPinned = useVizStore((s) => s.hudPinned);
	const revealHud = (0, import_react.useCallback)(() => {
		setHudVisible(true);
		if (hideTimer.current) window.clearTimeout(hideTimer.current);
		const state = useVizStore.getState();
		if (state.source === "idle" || !state.playing || state.hudPinned) return;
		hideTimer.current = window.setTimeout(() => setHudVisible(false), 2800);
	}, []);
	(0, import_react.useEffect)(() => {
		revealHud();
	}, [
		source,
		playing,
		hudPinned,
		revealHud
	]);
	(0, import_react.useEffect)(() => {
		audioEngine.setVolume(volume);
	}, [volume]);
	(0, import_react.useEffect)(() => {
		const onVis = () => {
			if (document.visibilityState === "visible") audioEngine.resume();
		};
		document.addEventListener("visibilitychange", onVis);
		return () => document.removeEventListener("visibilitychange", onVis);
	}, []);
	(0, import_react.useEffect)(() => {
		const onFs = () => {
			useVizStore.getState().setFullscreen(Boolean(document.fullscreenElement));
		};
		document.addEventListener("fullscreenchange", onFs);
		return () => document.removeEventListener("fullscreenchange", onFs);
	}, []);
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => {
			const el = audioEngine.audioEl;
			const state = useVizStore.getState();
			if (state.source === "file" && el) {
				state.setCurrentTime(el.currentTime || 0);
				if (el.duration && Number.isFinite(el.duration)) state.setFileMeta(state.fileName, el.duration);
				if (el.ended) state.setPlaying(false);
			}
		}, 200);
		return () => window.clearInterval(id);
	}, []);
	const startMic = (0, import_react.useCallback)(async () => {
		revealHud();
		const store = useVizStore.getState();
		store.setError(null);
		try {
			await audioEngine.startMic();
			store.setSource("mic");
			store.setPlaying(true);
			store.setFileMeta(null, 0);
		} catch {
			store.setError("Microphone is blocked or unavailable. Try uploading a track.");
			store.setSource("idle");
			store.setPlaying(false);
		}
	}, [revealHud]);
	const startDemo = (0, import_react.useCallback)(() => {
		revealHud();
		const store = useVizStore.getState();
		store.setError(null);
		audioEngine.startDemo();
		store.setSource("demo");
		store.setPlaying(true);
		store.setFileMeta(null, 0);
	}, [revealHud]);
	const loadFile = (0, import_react.useCallback)(async (file) => {
		revealHud();
		const store = useVizStore.getState();
		store.setError(null);
		try {
			const el = await audioEngine.loadFile(file);
			store.setSource("file");
			store.setPlaying(true);
			store.setFileMeta(file.name, el.duration || 0);
			el.onended = () => useVizStore.getState().setPlaying(false);
			el.onloadedmetadata = () => {
				useVizStore.getState().setFileMeta(file.name, el.duration || 0);
			};
		} catch {
			store.setError("Could not play that file. Try another audio format.");
			store.setSource("idle");
			store.setPlaying(false);
		}
	}, [revealHud]);
	const stop = (0, import_react.useCallback)(() => {
		audioEngine.stopAll();
		const store = useVizStore.getState();
		store.setSource("idle");
		store.setPlaying(false);
		store.setCurrentTime(0);
		store.setFileMeta(null, 0);
		setHudVisible(true);
	}, []);
	const togglePlay = (0, import_react.useCallback)(async () => {
		const store = useVizStore.getState();
		if (store.source === "idle") {
			startDemo();
			return;
		}
		if (store.playing) {
			audioEngine.pause();
			store.setPlaying(false);
			setHudVisible(true);
			return;
		}
		try {
			await audioEngine.resumePlayback();
			store.setPlaying(true);
		} catch {
			store.setError("Playback was interrupted. Tap play again.");
		}
	}, [startDemo]);
	const seek = (0, import_react.useCallback)((t) => {
		audioEngine.seek(t);
		useVizStore.getState().setCurrentTime(t);
	}, []);
	const toggleFullscreen = (0, import_react.useCallback)(async () => {
		const node = rootRef.current;
		if (!node) return;
		try {
			if (document.fullscreenElement) await document.exitFullscreen();
			else await node.requestFullscreen();
		} catch {
			useVizStore.getState().setError("Fullscreen is not available in this view.");
		}
	}, []);
	(0, import_react.useEffect)(() => {
		const onKey = (e) => {
			const tag = e.target?.tagName;
			if (tag === "INPUT" || tag === "TEXTAREA") return;
			if (e.code === "Space") {
				e.preventDefault();
				togglePlay();
			} else if (e.key === "f" || e.key === "F") toggleFullscreen();
			else if (e.key === "1") useVizStore.getState().setMode("spire");
			else if (e.key === "2") useVizStore.getState().setMode("orbit");
			else if (e.key === "3") useVizStore.getState().setMode("halo");
			else if (e.key === "Escape" && useVizStore.getState().source !== "idle") stop();
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [
		togglePlay,
		toggleFullscreen,
		stop
	]);
	const onDrop = (0, import_react.useCallback)((e) => {
		e.preventDefault();
		const file = e.dataTransfer.files?.[0];
		if (file && file.type.startsWith("audio")) loadFile(file);
	}, [loadFile]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		ref: rootRef,
		className: "grain relative min-h-dvh overflow-hidden bg-bg text-fg select-none",
		onPointerMove: revealHud,
		onPointerDown: revealHud,
		onDragOver: (e) => e.preventDefault(),
		onDrop,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VisualizerCanvas, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VisualizerHud, {
			visible: hudVisible,
			onMic: () => void startMic(),
			onUpload: (file) => void loadFile(file),
			onDemo: startDemo,
			onTogglePlay: () => void togglePlay(),
			onStop: stop,
			onSeek: seek,
			onFullscreen: () => void toggleFullscreen()
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VisualizerApp, {});
}
//#endregion
export { Home as component };
